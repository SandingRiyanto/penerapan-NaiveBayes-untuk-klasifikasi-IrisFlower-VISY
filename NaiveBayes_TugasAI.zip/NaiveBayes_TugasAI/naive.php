<!-- load library PHP-ML -->
<?php
    require_once './vendor/autoload.php';

    use Phpml\Classification\NaiveBayes;
    use Phpml\Dataset\Demo\IrisDataset;
    use Phpml\Metric\Accuracy;
?>

<!-- hftml -->
<html>
<head>
    <title>Iris Flower | NAIVE BAYES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>

<body>
    <div class="container">
    <br>
        <div class="row">
            <div class="col-md-6 offset-md-3">
            <h3 align="center">Deteksi <i>Iris Flower</i> | Naive Bayes Classifier</h3>
                <div class="card border-primary">
                    <div class="card-body">
                        <!-- form inputan -->
                        <form action="" method="post">
                            <table>
                                <tr> 
                                    <td>Sepal Length</td>
                                    <td>:</td>
                                    <td><input type="number" step="0.1" size="39" onkeypress="return harusAngka(event)" required="" placeholder="Sepal Length (cm)" name="params[]"></td>
                                </tr>
                                <tr> 
                                    <td>Sepal Width</td>
                                    <td>:</td>
                                    <td><input type="number" step="0.1" size="39" required="" onkeypress="return harusAngka(event)" placeholder="Sepal Width (cm)" name="params[]"></td>
                                </tr>
                                <tr> 
                                    <td>Petal Length</td>
                                    <td>:</td>
                                    <td><input type="number" step="0.1" size="39" required="" onkeypress="return harusAngka(event)" placeholder="Petal Length (cm)" name="params[]"></td>
                                </tr>
                                <tr> 
                                    <td>Petal Width</td>
                                    <td>:</td>
                                    <td><input type="number" step="0.1" size="39" required="" onkeypress="return harusAngka(event)" placeholder="Petal Width (cm)" name="params[]"></td>
                                </tr>
                                <tr> 
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <br><button type="submit" class="btn btn-sm btn-outline-success w-100 mb-2" name="proses" value="Proses!">PROSES</button>
                                        <br><button type="reset" onclick="window.location.href='naive.php';" class="btn btn-sm btn-outline-danger w-100">RESET</button>
                                    </td>
                                </tr>
                            </table>
                        </form>
                        <!-- end of form -->
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-md-12">
                        <marquee behavior="scroll" direction="left">
                            <p>Silahkan tekan tombol <b class="text-success">Proses</b> untuk mengetahui jenis <i><b>Iris Flower</b></i></p>
                        </marquee>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>

<!-- proses define iris dataset & load Naive Bayes - klasifikasi -->
<?php

if(isset($_POST['proses'])){

    $dataku = new IrisDataset();

    $samples= $dataku->getSamples();
    $labels = $dataku->getTargets();

    $ujicoba = array();
    foreach($_POST['params'] as $n){
        $ujicoba[] = $n;
    }
    
    $hasil = "unknown";
    
    $classifier = new NaiveBayes();
    $classifier->train($samples, $labels);

    $hasil = $classifier->predict($ujicoba);

    echo "<div class='container'><div class='col-md-6 offset-md-5'><b>Jenisnya adalah: <i class='text-primary'>{$hasil}</i></b><div></div>";
    if($hasil == "virginica"){
        echo"<div class='container'><img src='img/virginica.jpg' width='150'></div>";
    }
    else if($hasil == "versicolor"){
        echo"<div class='container'><img src='img/versicolor.jpg' width='150'></div>";
    }
    else{
        echo"<div class='container'><img src='img/setosa.jpg' width='140'></div>";
    }
}
?>

    </body>
</html>

<!-- validasi inputan -->
<script>
function harusAngka(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if ((charCode < 48 || charCode > 57)&&charCode>32)
    return false;
    return true;
}
</script>